# paoo

Projetos de Programação Orientada a Objetos Avançada utilizando [Angular](https://angular.io/)

## Desenvolvimento

1. Customize as variáveis de ambiente renomeando `.env.example` para `.env`

2. Utilizar os serviços disponíveis

    * **__paoo__**

        ```bash
        docker-compose run --rm --service-ports paoo bash
        ```
